/*
Grade Management System
Developed by Wu Yudong and his team named 1030. This program is developed for the Beijing Jiao Tong University Weihai campus Data Structure project. 
Using C. 
Developer List :
Wu Yudong		16711031@bjtu.edu.cn
Xu Zhuoran		16711035@bjtu.edu.cn
Xie Haochen		16711033@bjtu.edu.cn
Liao Xiangyu	16711016@bjtu.edu.cn
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<conio.h>
#include<string.h>
#define PI 3.1415926535
static int password1 = 123;
struct student
{
	int id;
	char name[20];
	float participation;
	float tutorial1;
	float tutorial2;
	float tutorial3;
	float tutorial4;
	float project;
	float exam;
	float grade;

}stu[200];
void writeExcel(int num);
void Sorting(int number);
void Distribution(int num);
void maxmin(int number);
void search();
void revise(int num);
void menu(int num);
void admin(int num);
int Normalize(int n);
void find(int num);
void aveage(int num);
void FailList(int num);
void main(){
	char filename[20];
	FILE*fp;
	int i,num,choice;
	printf("*********welcome to student information system*********\n");
	printf("input name of document: ");
	gets_s(filename);
	if ((fp = fopen(filename, "r")) == NULL)//ʶ���Ƿ��ܴ�
	{
		printf("cannot open file\n");
		
	}
	else printf("........................Loading.....................Finshed\n");
	printf("input the number of students\n");
	scanf_s("%d", &num);

	fseek(fp, 0, SEEK_SET);//�ǵ�ɾ����ͷ����
	for (i = 0; i <num; i++)
	{
		fscanf(fp, "%d", &stu[i].id);
		fscanf(fp, "%[^0-9]", &stu[i].name);//Ϊ��������֮��Ŀո��ȡ
		fscanf(fp, "%f", &stu[i].participation);
		fscanf(fp, "%f", &stu[i].tutorial1);
		fscanf(fp, "%f", &stu[i].tutorial2);
		fscanf(fp, "%f", &stu[i].tutorial3);
		fscanf(fp, "%f", &stu[i].tutorial4);
		fscanf(fp, "%f", &stu[i].project);
		fscanf(fp, "%f", &stu[i].exam);
		fscanf(fp, "%f", &stu[i].grade);
	};
	while(num!=10000){
		printf("************************************ M e n u **********************************\n"); 
		printf("*******************************************************************************\n");
		printf("******************************* 1.M a x & M i n *******************************\n");
		printf("******************************** 2.Distribution *******************************\n");
		printf("********************************** 3.Normalize ********************************\n");
		printf("********************************** 4.Searching ********************************\n");
		printf("********************************** 5.Pass Rate ********************************\n");
		printf("*********************************** 6.Sorting *********************************\n");
		printf("*********************************** 7.Average *********************************\n");
		printf("************************************ 8.Admin **********************************\n");
		printf("************************************ 9.Print **********************************\n");
		printf("************************************ 10.Reset **********************************\n");
		printf("************************************* 0.exit **********************************\n");
		printf("*******************************************************************************\n");
		printf("****participation/tutorial1/tutorial2/tutorial3/tutorial4/exam/project/grade***\n");

		printf_s("what function you want?\n");
		scanf_s("%d", &choice);
		switch (choice)
		{
		case 1:
			maxmin(num);
			break;
		case 2:
			Distribution(num);
			break;
		case 3:
			Normalize(num);
			break;
		case 4:
			search();
			break;
		case 5:
			find(num);
			break;
		case 6:
			Sorting(num);
			break;
		case 7:
			aveage(num);
			break;
		case 8:
			admin(num);
			break;
		case 9:
			writeExcel(num);
			break;
		case 10:
			fseek(fp, 0, SEEK_SET);//�ǵ�ɾ����ͷ����
			for (i = 0; i <num; i++)
			{
				fscanf(fp, "%d", &stu[i].id);
				fscanf(fp, "%[^0-9]", &stu[i].name);//Ϊ��������֮��Ŀո��ȡ
				fscanf(fp, "%f", &stu[i].participation);
				fscanf(fp, "%f", &stu[i].tutorial1);
				fscanf(fp, "%f", &stu[i].tutorial2);
				fscanf(fp, "%f", &stu[i].tutorial3);
				fscanf(fp, "%f", &stu[i].tutorial4);
				fscanf(fp, "%f", &stu[i].project);
				fscanf(fp, "%f", &stu[i].exam);
				fscanf(fp, "%f", &stu[i].grade);
			};
			break;
		case 0:
			exit(0);
		default:
			printf("Input wrong\n");
		}
		system("cls");
	};

	fclose(fp);
}
/*void writeExcel(int n)
{
	int i,j;
	//char filename[20];
	char* menuname[10] = { "Id", "Name", "participation", "tutorial1", "tutorial2", "tutorial3", "tutorial4", "project", "exam", "grade" };
	FILE *fpn = NULL;
	//printf("filename:");
	//gets(filename);
	fpn = fopen("text.xls", "w");
	for (j = 0; j < 10; j++)fprintf(fpn,"%s\t", menuname[j]);
	fprintf(fpn, "\n");
	for (i = 0; i < n; i++)
	{
	fprintf(fpn,"%d\t%s\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\n", stu[i].id, stu[i].name, stu[i].participation, stu[i].tutorial1, stu[i].tutorial2, stu[i].tutorial3, stu[i].tutorial4, stu[i].project, stu[i].exam, stu[i].grade);
	}
	printf(".....finish\n");
	fclose(fpn);
}*/
void writeExcel(int num)
{
	int i;
	char filename[20];
	FILE *fpn;
	printf("filename:");
	scanf("%s", filename);
	fpn = fopen(filename, "w");
	for (i = 0; i < num; i++)
	{
		fprintf(fpn, "%d\t%s\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\n", stu[i].id, stu[i].name, stu[i].participation, stu[i].tutorial1, stu[i].tutorial2, stu[i].tutorial3, stu[i].tutorial4, stu[i].project, stu[i].exam, stu[i].grade);
	}
	fclose(fpn);
}
void Sorting(int number)//ѧ������//
{
	char Type[20], Order[20];											
	printf("Input name of grades you want to sorting\n");
	scanf("%s", Type);
	printf("Ascending or Descending?\n");
	scanf("%s", Order);
	int i, j;
	struct student temp;
	if (strcmp(Order, "Descending") == 0)
	{
		if (strcmp(Type, "grade") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].grade <= stu[j + 1].grade)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "participation") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].participation <= stu[j + 1].participation)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "tutorial1") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].tutorial1 <= stu[j + 1].tutorial1)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "tutorial2") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].tutorial2 <= stu[j + 1].tutorial2)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "tutorial3") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].tutorial3 <= stu[j + 1].tutorial3)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "tutorial4") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].tutorial4 <= stu[j + 1].tutorial4)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "project") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].project <= stu[j + 1].project)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "exam") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].exam <= stu[j + 1].exam)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}
		else printf("wrong imput\n");
	}
	else if (strcmp(Order, "Ascending") == 0)
	{
		if (strcmp(Type, "grade") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].grade >= stu[j + 1].grade)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "participation") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].participation >= stu[j + 1].participation)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "tutorial1") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].tutorial1 >= stu[j + 1].tutorial1)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "tutorial2") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].tutorial2 >= stu[j + 1].tutorial2)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "tutorial3") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].tutorial3 >= stu[j + 1].tutorial3)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "tutorial4") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].tutorial4 >= stu[j + 1].tutorial4)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "project") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].project >= stu[j + 1].project)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}

		else if (strcmp(Type, "exam") == 0)
		{
			for (i = 0; i < number - 1; i++)
			for (j = 0; j < number - i - 1; j++)
			{
				if (stu[j].exam >= stu[j + 1].exam)
				{
					temp = stu[j];
					stu[j] = stu[j + 1];
					stu[j + 1] = temp;
				}
			}
		}
		else printf("wrong imput\n");
	}
	else printf("wrong imput\n");
	writeExcel(number);
	printf("continue? 1:yes 2:back\n");
	int c;
	scanf_s("%d", &c);
	if (c == 1)
	{
		return Sorting(number);
	}
	else
	    return;
}
void Distribution(int num)//ѧ������//
{
	char Type[20];
	printf("input name of grades you want to distribution\n");
	scanf("%s", Type);
	int i = 0, a = 0, b = 0, c = 0, d = 0, e = 0; //a(90-100�֣���b��80-90�֣���c��70-80�֣���d��60-70�֣���e��������<=60�֣�//
	if (strcmp(Type, "grade") == 0)
	{
		for (i = 0; stu[i].grade < 101 && stu[i].grade >= 0 && i <= num - 1; i++)
		{
			if (stu[i].grade >= 90) a++;
			else if (stu[i].grade >= 80) b++;
			else if (stu[i].grade >= 70) c++;
			else if (stu[i].grade >= 60) d++;
			else  e++;
		};
		printf("100--90score:   %d people\n 90--80score:   %d people\n 80--70score:   %d people\n 70--60score:   %d people\n Under 60:      %d people\n", a, b, c, d, e);
		
	}

	else if (strcmp(Type, "participation") == 0)
	{
		for (i = 0; stu[i].participation < 11 && stu[i].participation >= 0 && i <= num - 1; i++)
		{
			if (stu[i].participation >= 9) a++;
			else if (stu[i].participation >= 8) b++;
			else if (stu[i].participation >= 7) c++;
			else if (stu[i].participation >= 6) d++;
			else  e++;
		};
		printf("10--9score:  %d people\n9--8score:   %d people\n8--7score:   %d people\n7--6score:   %d people\nUnder 6:     %d people\n", a, b, c, d, e);
		
	}

	else if (strcmp(Type, "tutorial1") == 0)
	{
		for (i = 0; stu[i].tutorial1 < 6 && stu[i].tutorial1 >= 0 && i <= num - 1; i++)
		{
			if (stu[i].tutorial1 >= 5) a++;
			else if (stu[i].tutorial1 >= 4) b++;
			else if (stu[i].tutorial1 >= 3) c++;
			else if (stu[i].tutorial1 >= 2) d++;
			else e++;
		};
		printf("5 score:      %d people\n5--4  score:  %d people\n4--3  score:  %d people\n3--2  score:  %d people\nUnder 2:      %d people\n", a, b, c, d, e);
		
	}

	else if (strcmp(Type, "tutorial2") == 0)
	{
		for (i = 0; stu[i].tutorial2 < 6 && stu[i].tutorial2 >= 0 && i <= num - 1; i++)
		{
			if (stu[i].tutorial2 >= 5) a++;
			else if (stu[i].tutorial2 >= 4) b++;
			else if (stu[i].tutorial2 >= 3) c++;
			else if (stu[i].tutorial2 >= 2) d++;
			else  e++;
		};
		printf("5 score:      %d people\n5--4  score:  %d people\n4--3  score:  %d people\n3--2  score:  %d people\nUnder 2:      %d people\n", a, b, c, d, e);
		
	}

	else if (strcmp(Type, "tutorial3") == 0)
	{
		for (i = 0; stu[i].tutorial3 < 6 && stu[i].tutorial3 >= 0 && i <= num - 1; i++)
		{
			if (stu[i].tutorial3 >= 5) a++;
			else if (stu[i].tutorial3 >= 4) b++;
			else if (stu[i].tutorial3 >= 3) c++;
			else if (stu[i].tutorial3 >= 2) d++;
			else  e++;
		};
		printf("5 score:      %d people\n5--4  score:  %d people\n4--3  score:  %d people\n3--2  score:  %d people\nUnder 2:      %d people\n", a, b, c, d, e);
		
	}

	else if (strcmp(Type, "tutorial4") == 0)
	{
		for (i = 0; stu[i].tutorial4 < 6 && stu[i].tutorial4 >= 0 && i <= num - 1; i++)
		{
			if (stu[i].tutorial4 >= 5) a++;
			else if (stu[i].tutorial4 >= 4) b++;
			else if (stu[i].tutorial4 >= 3) c++;
			else if (stu[i].tutorial4 >= 2) d++;
			else  e++;
		};
		printf("5 score:      %d people\n5--4  score:  %d people\n4--3  score:  %d people\n3--2  score:  %d people\nUnder 2:      %d people\n", a, b, c, d, e);
		
	}

	else if (strcmp(Type, "project") == 0)
	{
		for (i = 0; stu[i].project < 21 && stu[i].project >= 0 && i <= num - 1; i++)
		{
			if (stu[i].project >= 18) a++;
			else if (stu[i].project >= 16) b++;
			else if (stu[i].project >= 14) c++;
			else if (stu[i].project >= 12) d++;
			else  e++;
		};
		printf("20--18score:  %d people\n18--16score:  %d people\n16--14score:  %d people\n14--12score:  %d people\nUnder 12:      %d people\n", a, b, c, d, e);
		
	}

	else if (strcmp(Type, "exam") == 0)
	{
		for (i = 0; stu[i].exam < 51 && stu[i].exam >= 0 && i <= num - 1; i++)
		{
			if (stu[i].exam >= 45) a++;
			else if (stu[i].exam >= 40) b++;
			else if (stu[i].exam >= 35) c++;
			else if (stu[i].exam >= 30) d++;
			else  e++;
		};
		printf("50--45score:  %d people\n45--40score:  %d people\n40--35score:  %d people\n35--30score:  %d people\nUnder 30:     %d people\n", a, b, c, d, e);
		
	}
	else printf("Wrong imput");
	printf("continue? 1:yes 2:back\n");
	int k;
	scanf_s("%d", &k);
	if (k == 1)
	{
		return Distribution(num);
	}
	else
		return;
}
void search()
{
	int a;
	printf("please input student id:");
	scanf("%d", &a);
	int i, N = 200;
	int b = 0;
	for (i = 0; i < N; i++)
	{

		if (a == stu[i].id)
		{
			printf("student name��\n");
			printf(	"******************** %s ********************\n", stu[i].name);
			printf("participation score			%.1f\t\n", stu[i].participation);
			printf("score in assignment 1			%.1f\n", stu[i].tutorial1);
			printf("score in assignment 2			%.1f\n", stu[i].tutorial2);
			printf("score in assignment 3			%.1f\n", stu[i].tutorial3);
			printf("score in assignment 4			%.1f\n", stu[i].tutorial4);
			printf("score in assignment course project	%.1f\n", stu[i].project);
			printf("score in final exam			%.1f\n", stu[i].exam);
			printf("final grade				%.1f\n", stu[i].grade);
			b = 1;
		}
	}
	if (b == 1)
	{
		printf("continue? 1:yes 2 : back\n");
		int c;
		scanf_s("%d", &c);
		if (c == 1)
		{
			return search();
		};
	}
	if (b == 0)
	{
		printf("no student! 1:resume 2:back\n");
		int d;
		scanf_s("%d", &d);
		if (d == 1)
		{
			return search();
		};

	}
}
void maxmin(int number)
{
	char Type[20];
	int i, j, judge,z;
	int a = 0;
	printf("Input name of grades you want to know\n");
	scanf("%s", Type);
	printf("1: max   2:min\n");
	scanf_s("%d", &judge);
	struct student temp;

	if (strcmp(Type, "grade") == 0)
	{
		for (i = 0; i < number - 1; i++)
		for (j = 0; j < number - i - 1; j++)
		{
			if (stu[j].grade <= stu[j + 1].grade)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		if (judge == 1){
			printf("Maximum\n");
			printf("the student name:%s\n", stu[0].name);
			printf("the student id:		%d\n", stu[0].id);
			printf("the student grade:	%.1f\n", stu[0].grade);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].grade == stu[0].grade){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].grade);
				}
			};
		};
		if (judge == 2){
		printf("Minimum\n");
		printf("the student name:%s\n", stu[number - 1].name);
		printf("the student ID:		%d\n", stu[number - 1].id);
		printf("the student grade:	%.1f\n", stu[number - 1].grade);
		a = 1;
		for (z = 1; z < number; z++)
		{
			if (stu[z].grade == stu[number - 1].grade){
				printf("***********************\n");
				printf("the student name:%s\n", stu[z].name);
				printf("the student id:		%d\n", stu[z].id);
				printf("the student grade:	%.1f\n", stu[z].grade);
			}
		};
		};
	}

	else if (strcmp(Type, "participation") == 0)
	{
		for (i = 0; i < number - 1; i++)
		for (j = 0; j < number - i - 1; j++)
		{
			if (stu[j].participation <= stu[j + 1].participation)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		if (judge == 1){
			printf("Maximum\n");
			printf("the student name:%s\n", stu[0].name);
			printf("the student id:		%d\n", stu[0].id);
			printf("the student grade:	%.1f\n", stu[0].participation);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].participation == stu[0].participation){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].participation);
				}
			};
		};
		if (judge == 2){
			printf("Minimum\n");
			printf("the student name:%s\n", stu[number - 1].name);
			printf("the student ID:		%d\n", stu[number - 1].id);
			printf("the student grade:	%.1f\n", stu[number - 1].participation);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].participation == stu[number-1].participation){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].participation);
				}
			};
		};
	}

	else if (strcmp(Type, "tutorial1") == 0)
	{
		for (i = 0; i < number - 1; i++)
		for (j = 0; j < number - i - 1; j++)
		{
			if (stu[j].tutorial1 <= stu[j + 1].tutorial1)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		if (judge == 1){
			printf("Maximum\n");
			printf("the student name:%s\n", stu[0].name);
			printf("the student id:		%d\n", stu[0].id);
			printf("the student grade:	%.1f\n", stu[0].tutorial1);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].tutorial1 == stu[0].tutorial1){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].tutorial1);
				}
			};
		};
		if (judge == 2){
			printf("Minimum\n");
			printf("the student name:%s\n", stu[number - 1].name);
			printf("the student ID:		%d\n", stu[number - 1].id);
			printf("the student grade:	%.1f\n", stu[number - 1].tutorial1);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].tutorial1 == stu[number - 1].tutorial1){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].tutorial1);
				}
			};
		};
	}

	else if (strcmp(Type, "tutorial2") == 0)
	{
		for (i = 0; i < number - 1; i++)
		for (j = 0; j < number - i - 1; j++)
		{
			if (stu[j].tutorial2 <= stu[j + 1].tutorial2)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		if (judge == 1){
			printf("Maximum\n");
			printf("the student name:%s\n", stu[0].name);
			printf("the student id:		%d\n", stu[0].id);
			printf("the student grade:	%.1f\n", stu[0].tutorial2);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].tutorial2 == stu[0].tutorial2){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].tutorial2);
				}
			};
		};
		if (judge == 2){
			printf("Minimum\n");
			printf("the student name:%s\n", stu[number - 1].name);
			printf("the student ID:		%d\n", stu[number - 1].id);
			printf("the student grade:	%.1f\n", stu[number - 1].tutorial2);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].tutorial2 == stu[number - 1].tutorial2){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].tutorial2);
				}
			};
		};
	}

	else if (strcmp(Type, "tutorial3") == 0)
	{
		for (i = 0; i < number - 1; i++)
		for (j = 0; j < number - i - 1; j++)
		{
			if (stu[j].tutorial3 <= stu[j + 1].tutorial3)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		if (judge == 1){
			printf("Maximum\n");
			printf("the student name:%s\n", stu[0].name);
			printf("the student id:		%d\n", stu[0].id);
			printf("the student grade:	%.1f\n", stu[0].tutorial3);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].tutorial3 == stu[0].tutorial3){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].tutorial3);
				}
			};
		};
		if (judge == 2){
			printf("Minimum\n");
			printf("the student name:%s\n", stu[number - 1].name);
			printf("the student ID:		%d\n", stu[number - 1].id);
			printf("the student grade:	%.1f\n", stu[number - 1].tutorial3);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].tutorial3 == stu[number-1].tutorial3){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].tutorial3);
				}
			};
		};
	}

	else if (strcmp(Type, "tutorial4") == 0)
	{
		for (i = 0; i < number - 1; i++)
		for (j = 0; j < number - i - 1; j++)
		{
			if (stu[j].tutorial4 <= stu[j + 1].tutorial4)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		if (judge == 1){
			printf("Maximum\n");
			printf("the student name:%s\n", stu[0].name);
			printf("the student id:		%d\n", stu[0].id);
			printf("the student grade:	%.1f\n", stu[0].tutorial4);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].tutorial4 == stu[0].tutorial4){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].tutorial4);
				}
			};
		};
		if (judge == 2){
			printf("Minimum\n");
			printf("the student name:%s\n", stu[number - 1].name);
			printf("the student ID:		%d\n", stu[number - 1].id);
			printf("the student grade:	%.1f\n", stu[number - 1].tutorial4);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].tutorial4 == stu[number-1].tutorial4){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].tutorial4);
				}
			};
		};
	}

	else if (strcmp(Type, "project") == 0)
	{
		for (i = 0; i < number - 1; i++)
		for (j = 0; j < number - i - 1; j++)
		{
			if (stu[j].project <= stu[j + 1].project)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		if (judge == 1){
			printf("Maximum\n");
			printf("the student name:%s\n", stu[0].name);
			printf("the student id:		%d\n", stu[0].id);
			printf("the student grade:	%.1f\n", stu[0].project);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].project == stu[0].project){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].project);
				}
			};
		};
		if (judge == 2){
			printf("Minimum\n");
			printf("the student name:%s\n", stu[number - 1].name);
			printf("the student ID:		%d\n", stu[number - 1].id);
			printf("the student grade:	%.1f\n", stu[number - 1].project);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].project == stu[number - 1].project){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].project);
				}
			};
		}
	}

	else if (strcmp(Type, "exam") == 0)
	{
		for (i = 0; i < number - 1; i++)
		for (j = 0; j < number - i - 1; j++)
		{
			if (stu[j].exam <= stu[j + 1].exam)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		if (judge == 1){
			printf("Maximum\n");
			printf("the student name:%s\n", stu[0].name);
			printf("the student id:		%d\n", stu[0].id);
			printf("the student grade:	%.1f\n", stu[0].exam);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].exam == stu[0].exam){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].exam);
				}
			};
		};
		if (judge == 2){
			printf("Minimum\n");
			printf("the student name:%s\n", stu[number - 1].name);
			printf("the student ID:		%d\n", stu[number - 1].id);
			printf("the student grade:	%.1f\n", stu[number - 1].exam);
			a = 1;
			for (z = 1; z < number; z++)
			{
				if (stu[z].exam == stu[number-1].exam){
					printf("***********************\n");
					printf("the student name:%s\n", stu[z].name);
					printf("the student id:		%d\n", stu[z].id);
					printf("the student grade:	%.1f\n", stu[z].exam);
				}
			};
		};
	}
	if (a == 1)
	{
		printf("continue? 1:yes 2:back\n");
		int c;
		scanf_s("%d", &c);
		if (c == 1)
		{
			return maxmin(number);
		};
	}
	if (a == 0)
	{
		printf("mistake! 1:resume 2:back\n");
		int d;
		scanf_s("%d", &d);
		if (d == 1)
		{
			return maxmin(number);
		};
	}
}
void admin(int num)
{
	int a;
	printf("please input your password:(only digits)");
	scanf_s("%d", &a);
	if (password1 == a)
	{
		printf("Correct password input!\n");
		menu(num);
	}
	else
	{
		printf("Password Error!\n");
		admin(num);
	}
}

void revise(int num)
{
	int a;
	printf("please input student id:");
	scanf_s("%d", &a);
	int b = 0;
	for (int j = 0; j < num; j++)
	{
		if (a == stu[j].id)
		{
			printf("student name: %s\n", stu[j].name);
			printf("input participation score:");
			scanf_s("%f", &stu[j].participation);
			printf("input score in score 1:");
			scanf_s("%f", &stu[j].tutorial1);
			printf("input score in score 2:");
			scanf_s("%f", &stu[j].tutorial2);
			printf("input score in score 3:");
			scanf_s("%f", &stu[j].tutorial3);
			printf("input score in score 4:");
			scanf_s("%f", &stu[j].tutorial4);
			printf("input score in project:");
			scanf_s("%f", &stu[j].project);
			printf("input score in exam:");
			scanf_s("%f", &stu[j].exam);
			printf("input grade:");
			scanf_s("%f", &stu[j].grade);
			b = 1;
		}
	}
	if (b == 0)
	{
		printf("no student!\n 1:resume 2:back\n");
		int c;
		scanf_s("%d", &c);
		if (c == 1)
			return revise(num);
			
	}
	printf("Finish!\n 1:continue 2:back\n");
	int d;
	scanf("%d", &d);
	if (d == 1)
		return revise(num);
	else
		
			return menu(num);

}
void menu(int num)
{
	printf("************* 1.change student grade *************\n");
	printf("**************** 2.reset password ****************\n");
	printf("******************** 3.faillist ******************\n");
	printf("******************** 4.//return ******************\n");
	int a;
	scanf_s("%d", &a);
	if (a == 1)
		return revise(num);
	else if (a == 2)
	{
		printf("please input old password:");
		int b;
		scanf_s("%d", &b);
		if (b == password1)
		{
			printf("Correct password input!");
			printf("please input new password:");
			int c;
			scanf("%d", &c);
			printf("please input password again:");
			int d;
			scanf("%d", &d);
			if (c == d)
			{
				printf("success!\n");
				password1 = d;
				menu(num);
			}
			else
			{
				printf("Your new password and confirmed new password do not match!\n");
				printf("return!");
				menu(num);
			}
		}
		else
		{
			printf("Password Error!");
			menu(num);
		}
	}
	else if (a == 3){
		FailList(num);
	}
	printf("continue? 1:yes 2:back\n");
	int c;
	scanf_s("%d", &c);
	if (c == 1)
	{
		return menu(num);
	}
	else
		return ;

}
double gaussrand(double u2, double E)
{
	static double U, V;
	static int phase = 0;
	double Z;
	if (phase == 0)
	{
		U = (rand()) / ((RAND_MAX) / 1.0);
		V = (rand()) / ((RAND_MAX) / 1.0);
		Z = sqrt(-2.0*log(U))*sin(2.0*PI*V);

	}
	else
	{
		Z = sqrt(-2.0*log(U))*cos(2.0*PI*V);
	}
	phase = 1 - phase;
	double X = E + Z*sqrt(u2);
	return X >= 0 ? X : -X;
}
int Normalize(int n)
{
	char Type[20]; 
 
	struct student temp;
	float u2, E;
	float a[200],temp1;
	int i, j;
	printf("what grades you want to normalize\n");
	scanf("%s", Type);
	printf("input variance and expectation");
	printf("(input space in the two data)\n");
	scanf("%f %f", &u2, &E);
	if (strcmp(Type, "grade") == 0)
	{
	
					for (i = 0; i < n - 1; i++)
					for (j = 0; j < n - i - 1; j++)
					{
						if (stu[j].grade <= stu[j + 1].grade)
						{
							temp = stu[j];
							stu[j] = stu[j + 1];
							stu[j + 1] = temp;
						}
					}
					for (i = 0; i<n; i++)
					{
						a[i] = fmod(gaussrand(u2, E), 100.0);
					};
					for (i = 0; i < n - 1; i++)
					for (j = 0; j < n - i - 1; j++)
					{
						if (a[j] <= a[j + 1])
						{
							temp1 = a[j];
							a[j] = a[j + 1];
							a[j + 1] = temp1;
						}
					}
					for (i = 0; i < n; i++)
					{
						stu[i].grade = a[i];
						printf("%.2f\n", stu[i].grade);
					};
	}
	if (strcmp(Type, "participation") == 0)
	{

		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (stu[j].participation <= stu[j + 1].participation)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		for (i = 0; i<n; i++)
		{
			a[i] = fmod(gaussrand(u2, E), 100.0);
		};
		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (a[j] <= a[j + 1])
			{
				temp1 = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp1;
			}
		}
		for (i = 0; i < n; i++)
		{
			stu[i].participation = a[i];
			printf("%.2f\n", stu[i].participation);
		};
	}
	if (strcmp(Type, "tutorial1") == 0)
	{

		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (stu[j].tutorial1 <= stu[j + 1].tutorial1)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		for (i = 0; i<n; i++)
		{
			a[i] = fmod(gaussrand(u2, E), 100.0);
		};
		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (a[j] <= a[j + 1])
			{
				temp1 = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp1;
			}
		}
		for (i = 0; i < n; i++)
		{
			stu[i].tutorial1 = a[i];
			printf("%.2f\n", stu[i].tutorial1);
		};
	}
	if (strcmp(Type, "tutorial2") == 0)
	{

		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (stu[j].tutorial2 <= stu[j + 1].tutorial2)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		for (i = 0; i<n; i++)
		{
			a[i] = fmod(gaussrand(u2, E), 100.0);
		};
		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (a[j] <= a[j + 1])
			{
				temp1 = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp1;
			}
		}
		for (i = 0; i < n; i++)
		{
			stu[i].tutorial2 = a[i];
			printf("%.2f\n", stu[i].tutorial2);
		};
	}
	if (strcmp(Type, "tutorial3") == 0)
	{

		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (stu[j].tutorial3 <= stu[j + 1].tutorial3)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		for (i = 0; i<n; i++)
		{
			a[i] = fmod(gaussrand(u2, E), 100.0);
		};
		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (a[j] <= a[j + 1])
			{
				temp1 = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp1;
			}
		}
		for (i = 0; i < n; i++)
		{
			stu[i].tutorial3 = a[i];
			printf("%.2f\n", stu[i].tutorial3);
		};
	}
	if (strcmp(Type, "tutorial4") == 0)
	{

		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (stu[j].tutorial4 <= stu[j + 1].tutorial4)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		for (i = 0; i<n; i++)
		{
			a[i] = fmod(gaussrand(u2, E), 100.0);
		};
		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (a[j] <= a[j + 1])
			{
				temp1 = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp1;
			}
		}
		for (i = 0; i < n; i++)
		{
			stu[i].tutorial4 = a[i];
			printf("%.2f\n", stu[i].tutorial4);
		};
		
			};
	if (strcmp(Type, "project") == 0)
	{

		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (stu[j].project <= stu[j + 1].project)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		for (i = 0; i<n; i++)
		{
			a[i] = fmod(gaussrand(u2, E), 100.0);
		};
		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (a[j] <= a[j + 1])
			{
				temp1 = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp1;
			}
		}
		for (i = 0; i < n; i++)
		{
			stu[i].project = a[i];
			printf("%.2f\n", stu[i].project);
		}
	}
	if (strcmp(Type, "exam") == 0)
	{

		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (stu[j].exam <= stu[j + 1].exam)
			{
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
		for (i = 0; i<n; i++)
		{
			a[i] = fmod(gaussrand(u2, E), 100.0);
		};
		for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
		{
			if (a[j] <= a[j + 1])
			{
				temp1 = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp1;
			}
		}
		for (i = 0; i < n; i++)
		{
			stu[i].exam = a[i];
			printf("%.2f\n", stu[i].exam);
		};
	}
	printf("continue? 1:yes 2:back\n");
	int c;
	scanf_s("%d", &c);
	if (c == 1)
	{
		return Normalize(n);
	}
	else
		return 0;
	
}
void find(int num)
{
	float a=0,b=0;
	for (int i = 0; i<num; i++)
	if (stu[i].grade < 60)
	{
		a++;
	}
	else
	{
		b++;
	}
	printf("The number of failures is:%.0f\n", a);
	printf("The number of passing is:%.0f\n", b);
	printf("The pass rate is:%.2f%%\n", b/(a+b)*100);
	printf("continue? 1:yes 2:back\n");
	int c;
	scanf_s("%d", &c);
	if (c == 1)
	{
		return find(num);
	}
	else
		return;

}
void aveage(int num)
{
	float sum1 = 0, sum2 = 0, sum3 = 0, sum4 = 0, sum5 = 0, sum6 = 0, sum7 = 0, sum8 = 0;
	for (int i = 0; i < num; i++)
	{
		sum1 += stu[i].participation;
		sum2 += stu[i].tutorial1;
		sum3 += stu[i].tutorial2;
		sum4 += stu[i].tutorial3;
		sum5 += stu[i].tutorial4;
		sum6 += stu[i].project;
		sum7 += stu[i].exam;
		sum8 += stu[i].grade;
	}
	printf("participation score			%.1f\t\n", sum1 / num);
	printf("score in assignment 1			%.1f\n", sum2 / num);
	printf("score in assignment 2			%.1f\n", sum3 / num);
	printf("score in assignment 3			%.1f\n", sum4 / num);
	printf("score in assignment 4			%.1f\n", sum5 / num);
	printf("score in assignment course project	%.1f\n", sum6 / num);
	printf("score in final exam			%.1f\n", sum7 / num);
	printf("final grade				%.1f\n", sum8 / num);
	printf("\n");
	printf("1.back\n");
	int c;
	scanf_s("%d", &c);
	if (c == 1)
	{
		return;
	}
}
void FailList(int num)//��Ҫ1.������������гɼ��Լ�2.����ɼ������ֳɼ�(��Ҫ����������룩//
{
	int i = 0, e = 0; //a(90-100�֣���b��80-90�֣���c��70-80�֣���d��60-70�֣���e��������<=60�֣�//
	printf("��������Ϊ\n");
	for (i = 0; stu[i].grade < 101 && stu[i].grade >= 0 && i <= num - 1; i++)
	{
		if (stu[i].grade < 60)
			printf("%d, %s\n", stu[i].id, stu[i].name);
	}
	return;
}






